library(readxl)
Final<-read_excel("C:\\Users\KSM\Downloads\Final.xlsx")
View(Final)


install.packages("ggplot2")
install.packages("dplyr")
install.packages("broom")
install.packages("ggpubr")

summary(Final)

#################################### To find Correlation Matrix #############################################
install.packages("corrplot")
library(corrplot)


m<-cor(Final)
m
n<-corrplot(m, method = "circle")

#################################################### Checking for Normality condition using Shapiro Wilk test ##############################################

shapiro.test(Final$`Depressive dis.`)
shapiro.test(Final$`Total alcohol consumption per capita`)
shapiro.test(Final$`Deaths - Suicide`)
shapiro.test(Final$`M & Sub. Dis`)
shapiro.test(Final$`Economy (GDP per Capita)`)
shapiro.test(Final$Family)
shapiro.test(Final$`% Total Pop.(Male)`)


#################################################### Alternate way to check for normality (visually) ################################
hist(Final$`Depressive dis.`)
hist(Final$`Deaths - Suicide`)
hist(Final$`Total alcohol consumption per capita`)
hist(Final$`M & Sub. Dis`)
hist(Final$`Economy (GDP per Capita)`)
hist(Final$Family)
hist(Final$`% Total Pop.(Male)`)

################################### Running A Regression ##############################################


My_model <- lm(`Deaths - Suicide` ~  `% Total Pop.(Male)` + `Depressive dis.`  + `Total alcohol consumption per capita` + `M & Sub. Dis` + `Economy (GDP per Capita)` +
                 Family  , data = Final)

summary(My_model)
head(resid(My_model))
coef(My_model)
sigma(My_model)
anova(My_model)
fitted(My_model)



################################### create scatterplot matrix
pairs(Final[c("% Total Pop.(Male)", "Depressive dis.", "Total alcohol consumption per capita", "M & Sub. Dis", "Economy (GDP per Capita)", "Family")], main="Scatterplot Matrix")

# create first data frame
plotting.data1 <- expand.grid(
  `Total alcohol consumption per capita` = seq(min(Final$`Total alcohol consumption per capita`), max(Final$`Total alcohol consumption per capita`), length.out = 30),
  `% Total Pop.(Male)` = seq(min(Final$`% Total Pop.(Male)`), max(Final$`% Total Pop.(Male)`), length.out = 30),
  `Depressive dis.` = seq(min(Final$`Depressive dis.`), max(Final$`Depressive dis.`), length.out = 30))


# create second data frame
plotting.data2<-expand.grid(`M & Sub. Dis` = seq(min(Final$`M & Sub. Dis`), max(Final$`M & Sub. Dis`), length.out = 30),
                            `Economy (GDP per Capita)` = seq(min(Final$`Economy (GDP per Capita)`), max(Final$`Economy (GDP per Capita)`), length.out = 30),
                            Family = seq(min(Final$Family), max(Final$Family), length.out = 30)
)


# merge the two data frames
plotting.data<- cbind(plotting.data1,plotting.data2)
plotting.data



################################################################ Residual vs Fitted ######################################################

par(mfrow=c(1,1))
plot(My_model)
par(mfrow=c(1,1))



################################################################################# Create scatter plot with regression line ##############################################################
ggplot(Final, aes(x = `% Total Pop.(Male)`, y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and male population",
       x = "Male population (%)",
       y = "Suicide deaths") +
  theme_minimal()

ggplot(Final, aes(x = `Depressive dis.`, y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and Depressive Dis.",
       x = "Depressive Dis.",
       y = "Suicide deaths") +
  theme_minimal()

ggplot(Final, aes(x = `Total alcohol consumption per capita` , y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and Total alcohol consumption",
       x = "Total alcohol consumption per capita ",
       y = "Suicide deaths") +
  theme_minimal()


ggplot(Final, aes(x = `M & Sub. Dis` , y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and M & Sub. Dis",
       x = "M & Sub. Dis ",
       y = "Suicide deaths") +
  theme_minimal()

ggplot(Final, aes(x = `Economy (GDP per Capita)` , y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and Economy (GDP per Capita)",
       x = "Economy (GDP per Capita)",
       y = "Suicide deaths") +
  theme_minimal()

ggplot(Final, aes(x = `Family` , y = `Deaths - Suicide`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Regression of suicide deaths and Family",
       x = "Family",
       y = "Suicide deaths") +
  theme_minimal()
